﻿using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace JP.Shared
{
    public class employee
    {
        public decimal id { get; set; }
        public string email { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int otherNumber { get; set; }
        public employee(decimal _id, string _email, string _firstName, string _lastName, int _otherNumber)
        {
            id = _id;
            email = _email;
            firstName = _firstName;
            lastName = _lastName;
            otherNumber = _otherNumber;
        }
    }

    public class product
    {
        public decimal id { get; set; }
        public string name { get; set; }
        public int price { get; set; }
        public int category { get; set; }
        public string categoryName { get; set; }
        public DateTime date { get; set; }
        public string description { get; set; }
        public product(decimal _id, string _name, int _price, int _category, DateTime _date, string _description)
        {
            id = _id;
            name = _name;
            price = _price;
            category = _category;
            categoryName = category == 0 ? "NULL" :
                category == 1 ? "Construction" :
                category == 2 ? "Retail" :
                category == 3 ? "Professional Services" :
                category == 4 ? "Personal Services" :
                category == 5 ? "Business to Business" :
                category == 6 ? "Restaurants & Quick-Serve Restaurants" :
                "Other";
            date = _date;
            description = _description;
        }
    }

    public class database
    {
        public static List<employee> GetEmployees()
        {
            List<employee> employees = new List<employee>();
            try
            {
                var connectionString = @"Server=tcp:jp-morgan.database.windows.net,1433;Initial Catalog=JP-Morgan;Persist Security Info=False;User ID=JPMorgan;Password=SeniorProject#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    var query = "SELECT * FROM employee;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                employees.Add(new employee(reader.GetDecimal(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetInt32(4)));
                            }
                        }
                    }
                    connection.Close();
                    return employees;
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.ReadLine();
            return employees;
        }

        public static List<product> GetProducts(int category = 0) // Optional parameter is set to 0 by default
        {
            List<product> products = new List<product>();
            try
            {
                var connectionString = @"Server=tcp:jp-morgan.database.windows.net,1433;Initial Catalog=JP-Morgan;Persist Security Info=False;User ID=JPMorgan;Password=SeniorProject#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    var query = "SELECT * FROM product";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                products.Add(new product(reader.GetDecimal(0), reader.GetString(1), reader.GetInt32(2), reader.GetInt32(3), reader.GetDateTime(4), reader.GetString(5)));
                            }
                        }
                    }
                    connection.Close();
                    // Removing products that don't match the category. 
                    // 0 is for all products
                    if (category > 0)
                    {
                        products.RemoveAll(p => p.category != category);
                    }
                    return products;
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.ReadLine();
            return products;
        }
    }
}
